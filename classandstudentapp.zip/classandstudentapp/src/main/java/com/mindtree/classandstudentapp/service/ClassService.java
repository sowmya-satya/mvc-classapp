package com.mindtree.classandstudentapp.service;

import com.mindtree.classandstudentapp.dto.ClassDto;

public interface ClassService {

	String addClassDetails(ClassDto classDto);

}
