package com.mindtree.classandstudentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassandstudentappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassandstudentappApplication.class, args);
	}

}
