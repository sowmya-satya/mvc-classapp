package com.mindtree.passwordgenerationapp.service;

import com.mindtree.passwordgenerationapp.entity.Person;

public interface PersonService {

	/**
	 * @param person
	 * @return
	 */
	Person addDetails(Person person);

	/**
	 * @param passportNumber
	 * @return
	 */
	Person getDetails(String passportNumber);

}
