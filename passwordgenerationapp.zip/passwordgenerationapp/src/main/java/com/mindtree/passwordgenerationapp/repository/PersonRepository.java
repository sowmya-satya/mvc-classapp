package com.mindtree.passwordgenerationapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.passwordgenerationapp.entity.Person;

@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {

	Person findBypassportNumber(String passportNumber);

}
