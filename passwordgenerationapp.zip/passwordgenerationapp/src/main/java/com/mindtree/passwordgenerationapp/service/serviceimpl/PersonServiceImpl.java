package com.mindtree.passwordgenerationapp.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.passwordgenerationapp.entity.Person;
import com.mindtree.passwordgenerationapp.repository.PersonRepository;
import com.mindtree.passwordgenerationapp.service.PersonService;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonRepository personRepository;

	@Override
	public Person addDetails(Person person) {

		String passportNumber = "";
		for (int i = 0; i < 1; i++) {
			passportNumber = passportNumber + person.getFirstName().charAt(i);
		}

		for (int i = 0; i < 1; i++) {
			passportNumber = passportNumber + person.getLastName().charAt(i);
		}

		passportNumber = passportNumber + person.getAge();

		for (int i = 0; i < 2; i++) {
			passportNumber = passportNumber + person.getCountry().charAt(i);
		}
		person.setPassportNumber(passportNumber);
		personRepository.save(person);
		return person;
	}

	@Override
	public Person getDetails(String passportNumber) {

		Person person = personRepository.findBypassportNumber(passportNumber);

		return person;
	}

}
