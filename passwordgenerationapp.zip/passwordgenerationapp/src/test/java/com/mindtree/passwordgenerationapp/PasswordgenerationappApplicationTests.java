package com.mindtree.passwordgenerationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordgenerationappApplicationTests {

	@Test
	void contextLoads() {
	}

}
